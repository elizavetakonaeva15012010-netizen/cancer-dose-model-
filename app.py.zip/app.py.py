import numpy as np
import streamlit as st
from dataclasses import dataclass
import matplotlib.pyplot as plt

st.title("OncoThera")
st.caption("⚠ Не является медицинской рекомендацией. Только исследовательская модель.")

@dataclass
class Isotope:
    name: str
    half_life_days: float
    energy_MeV: float
    alpha_beta: float
    radiation_type: str
    penetration_mm: float
    marrow_toxicity: float

# ==============================
isotopes = [
    Isotope("I-131", 8.02, 0.61, 10, "beta", 2.0, 1.2),
    Isotope("Lu-177", 6.65, 0.49, 10, "beta", 1.5, 1.1),
    Isotope("Y-90", 2.67, 0.94, 10, "beta", 11.0, 2.0),
    Isotope("Ra-223", 11.4, 5.78, 5, "alpha", 0.1, 0.8),
    Isotope("Ac-225", 10.0, 5.83, 5, "alpha", 0.05, 1.5),
    Isotope("At-211", 0.30, 5.87, 5, "alpha", 0.05, 1.3),
    Isotope("Sm-153", 1.95, 0.81, 10, "beta", 3.0, 1.4),
]

# ==============================
# Данные пациента
# ==============================
st.sidebar.header("Данные пациента")

# Диаметр опухоли
diameter = st.sidebar.number_input("Диаметр опухоли (см)", value=2.0, min_value=0.1, max_value=20.0, step=0.1)

# Стадия опухоли
stage = st.sidebar.selectbox("Стадия", [1, 2, 3, 4])

# Возраст пациента
age = st.sidebar.number_input("Возраст (лет)", value=60, min_value=0, max_value=120, step=1)

# Количество метастаз
metastases = st.sidebar.number_input("Количество метастаз", value=0, min_value=0, max_value=50, step=1)

# Особенности пациента
diabetes = st.sidebar.checkbox("Диабет")
renal = st.sidebar.checkbox("Почечная недостаточность")
hepatic = st.sidebar.checkbox("Печёночная недостаточность")

# Новый параметр — вес пациента
weight = st.sidebar.number_input("Вес пациента (кг)", value=70.0, min_value=30.0, max_value=200.0, step=0.5)

# Рост пациента (опционально, можно использовать для ИМТ или коррекции дозы)
height = st.sidebar.number_input("Рост пациента (см)", value=170, min_value=120, max_value=220, step=1)

# ==============================
# Расчет массы опухоли
# ==============================
def tumor_mass(diameter_cm):
    radius_cm = diameter_cm / 2
    volume_cm3 = (4/3) * np.pi * radius_cm**3
    density = 1.05  # г/см³
    return volume_cm3 * density / 1000  # кг

tumor_mass_kg = tumor_mass(diameter)

# Общая масса для расчета дозы
# Можно использовать только вес пациента или суммарно с массой опухоли
total_mass_kg = weight  # кг
# ==============================
def patient_risk():
    r = 1.0
    if age > 70: r += 0.2
    if diabetes: r += 0.15
    if renal: r += 0.3
    if hepatic: r += 0.25
    return r
risk_factor = patient_risk()

def tumor_mass(d):
    r = d / 2
    volume = (4/3) * np.pi * r**3
    density = 1.05
    return volume / 1000 * density

def effective_half_life(T_phys, T_bio=5.0):
    return (T_phys * T_bio) / (T_phys + T_bio)

def accumulated_dose(activity_mbq, isotope, mass_kg, T_eff):
    A0 = activity_mbq * 1e6
    energy_J = isotope.energy_MeV * 1.602e-13
    lam = np.log(2) / T_eff
    t = np.linspace(0, 10*T_eff, 1500)
    A = A0 * np.exp(-lam*t)
    dt = t[1]-t[0]
    return np.sum(A)*dt*energy_J/mass_kg

def optimize_activity(isotope, mass, target, T_eff):
    low, high = 1, 50000
    for _ in range(60):
        mid = (low + high)/2
        d = accumulated_dose(mid, isotope, mass, T_eff)
        if d < target:
            low = mid
        else:
            high = mid
    return mid

def TCP(dose, alpha_beta):
    alpha = 0.3
    return 1 - np.exp(-alpha*dose)

def NTCP(dose, toxicity, risk):
    TD50 = 70 / toxicity
    m = 0.2
    return 1 / (1 + np.exp(-(dose - TD50)/(m*TD50))) * risk

def metastasis_penalty(mets, radiation_type):
    if mets == 0: return 0
    return mets * (0.5 if radiation_type=="alpha" else 1.0)

# ==============================
target_dose = 60 if stage in [1,2] else 80
target_dose /= risk_factor
mass = tumor_mass(diameter)

results = []
for iso in isotopes:
    T_eff = effective_half_life(iso.half_life_days)
    activity = optimize_activity(iso, mass, target_dose, T_eff)
    dose = accumulated_dose(activity, iso, mass, T_eff)
    tcp = TCP(dose, iso.alpha_beta)
    ntcp = NTCP(dose, iso.marrow_toxicity, risk_factor)
    meta_pen = metastasis_penalty(metastases, iso.radiation_type)
    score = (1 - tcp) + ntcp + meta_pen + activity/20000
    results.append((iso, activity, dose, tcp, ntcp, score))

results.sort(key=lambda x: x[5])
best = results[0]

# ==============================
st.subheader("Персонализированная рекомендация")
st.write(f"Изотоп: {best[0].name}")
st.write(f"Тип: {best[0].radiation_type}")
st.write(f"Рекомендуемая активность: {best[1]:.1f} МБк")
st.write(f"Расчётная доза: {best[2]:.1f} Гр")
st.write(f"TCP (контроль опухоли): {best[3]:.2f}")
st.write(f"NTCP (риск осложнений): {best[4]:.2f}")
st.write(f"Итоговый клинический score: {best[5]:.3f}")

st.subheader("Альтернативные изотопы по приоритету")
for alt in results[1:]:
    st.write(f"{alt[0].name} | TCP={alt[3]:.2f} | NTCP={alt[4]:.2f} | Активность={alt[1]:.1f} МБк | score={alt[5]:.3f}")

# ==============================
st.subheader("Визуализация")
tcp_vals = [r[3] for r in results]
ntcp_vals = [r[4] for r in results]
names = [r[0].name for r in results]
activities = [r[1] for r in results]
doses = [r[2] for r in results]

# 1. TCP vs NTCP
fig1, ax1 = plt.subplots()
ax1.scatter(ntcp_vals, tcp_vals, color='teal')
for i, txt in enumerate(names):
    ax1.annotate(txt, (ntcp_vals[i], tcp_vals[i]))
ax1.set_xlabel("NTCP (риск осложнений)")
ax1.set_ylabel("TCP (контроль опухоли)")
ax1.set_title("TCP vs NTCP")
fig1.savefig("tcp_vs_ntcp.png")
st.image("tcp_vs_ntcp.png", caption="TCP vs NTCP")

# 2. Активность
fig2, ax2 = plt.subplots()
ax2.bar(names, activities, color='orange')
ax2.set_ylabel("Активность (МБк)")
ax2.set_title("Активность каждого изотопа")
fig2.savefig("activity.png")
st.image("activity.png", caption="Активность изотопов")

# 3. Доза
fig3, ax3 = plt.subplots()
ax3.bar(names, doses, color='green')
ax3.set_ylabel("Расчётная доза (Гр)")
ax3.set_title("Доза каждого изотопа")
fig3.savefig("dose.png")
st.image("dose.png", caption="Доза изотопов")